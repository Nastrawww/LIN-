/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

COM_InitTypeDef BspCOMInit;
UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */
uint8_t txbuffer[20];
uint8_t buffer[12];
uint8_t Data[12];
uint8_t rxdata[20];
uint8_t Blue[8]={0x01 , 0x80, 0x78, 0x29, 0x19, 0xF1 ,0xD2, 0x03};
uint8_t White[8]={0x01 , 0xF0, 0xFF, 0xFF, 0x18, 0x00 ,0x00, 0x00};
uint8_t Red[8]={0x01 , 0xF0, 0x03, 0xC0, 0x18, 0x00 ,0x00, 0x00};
uint8_t Green[8]={0x01 , 0x00, 0xFC, 0xC0, 0x18, 0x00 ,0x00, 0x00};
uint8_t numDataBytes=0;
uint8_t ID=0;
uint8_t isDataValid = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */



void wait(void)
{
	for(uint32_t i = 0 ; i < 500 ; i ++);
}
uint8_t PID_CALC(uint8_t id)
{
	if(id > 0x3F)
	{
		Error_Handler();
	}
	 uint8_t  ID_Buf[6];
	 for(int i=0 ; i< 6;i++)
	 {
		 ID_Buf[i]= (id>>i)& 0x01;
	 }
	uint8_t P0 = (ID_Buf[0]^ID_Buf[1]^ID_Buf[2]^ID_Buf[4])&0x01;
	uint8_t P1 = ~((ID_Buf[1]^ID_Buf[3]^ID_Buf[4]^ID_Buf[5])&0x01);
	id = id | (P0<<6) |(P1<<7) ;

	return id;
}

uint8_t	Enhanced_checksum(uint8_t PID, uint8_t *data , uint8_t size)
{
	uint8_t buffer[size+2];
	uint16_t sum=0 ;
	buffer[0]= PID;
	for(int i=0 ; i<size ; i++)
	{
		buffer[i+1]= data[i];
	}
	for(int i=0 ; i<size+1 ; i++)
	{
		sum =sum+ buffer[i];
		if(sum >0xFF)
			sum =sum-0xFF;
	}
	sum =0xFF- sum ;   // inversion of result
	return sum;

}
void frame(void)
{
	  txbuffer[0]=0x55; //sync field
	  txbuffer[1]= PID_CALC(0x00);
}
 void LIN_Transmit()
 {
	  txbuffer[10]= Enhanced_checksum(txbuffer[1] , txbuffer+2 ,8);
	  HAL_LIN_SendBreak(&huart1);
	  HAL_UART_Transmit(&huart1, txbuffer, 11, 1000);
	  HAL_Delay(100);
 }
 void LIN_RECEIVE()
 {
	 /*
	 if((HAL_UART_Receive(&huart1, buffer,12,500)) == HAL_OK)
	 {
		 uint8_t checksum = Enhanced_checksum(buffer[2], buffer+3 , 2);
		 if(checksum == buffer[11])
		 {
			 for(int i =0 ; i<8 ; i++)
			 {
			     rxdata[i]=buffer[i+3];
			 }
		 }
	 }
	 */
	 if (isDataValid == 1)
		  {
			  for (int i=0; i<numDataBytes; i++)
			  {
				  Data[i] = rxdata[i+3];
			  }
			  isDataValid = 0;
		  }

 }
void Green_colour()
{
	  frame();
	  for(int i =0 ; i<8 ;i++)
	  {
		  txbuffer[i+2]= Green[i];
	  }
	  LIN_Transmit();
}
void Blue_colour()
{
	frame();
	  for(int i =0 ; i<8 ;i++)
	  {
		  txbuffer[i+2]= Blue[i];
	  }
	  LIN_Transmit();
}
void Red_colour()
{
	frame();
	  for(int i =0 ; i<8 ;i++)
	  {
		  txbuffer[i+2]= Red[i];
	  }
	  LIN_Transmit();
}
void White_colour()
{
	frame();
	  for(int i =0 ; i<8 ;i++)
	  {
		  txbuffer[i+2]= White[i];
	  }
	  LIN_Transmit();
}
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
	numDataBytes = Size - 4;
	uint8_t checksum = Enhanced_checksum(rxdata[2], rxdata+3, numDataBytes);
	if (checksum != rxdata[Size-1])
    {
		isDataValid = 0;
			// call error handler
	}
	else isDataValid = 1;
	ID = rxdata[2]&0x3F;
	HAL_UARTEx_ReceiveToIdle_IT(&huart1, rxdata, 20);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */


  /* USER CODE END 2 */

  /* Initialize led */
  BSP_LED_Init(LED_GREEN);

  /* Initialize USER push-button, will be used to trigger an interrupt each time it's pressed.*/
  BSP_PB_Init(BUTTON_USER, BUTTON_MODE_EXTI);

  /* Initialize COM1 port (115200, 8 bits (7-bit data + 1 stop bit), no parity */
  BspCOMInit.BaudRate   = 115200;
  BspCOMInit.WordLength = COM_WORDLENGTH_8B;
  BspCOMInit.StopBits   = COM_STOPBITS_1;
  BspCOMInit.Parity     = COM_PARITY_NONE;
  BspCOMInit.HwFlowCtl  = COM_HWCONTROL_NONE;
  if (BSP_COM_Init(COM1, &BspCOMInit) != BSP_ERROR_NONE)
  {
    Error_Handler();
  }

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  HAL_UARTEx_ReceiveToIdle_IT(&huart1, rxdata, 20);
  while (1)
  {
	  //Blue_colour();
	  //Red_colour();
	 // Green_colour();
	  White_colour();
	  wait();
	  LIN_RECEIVE();
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV4;
  RCC_OscInitStruct.PLL.PLLN = 85;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 19200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_LIN_Init(&huart1, UART_LINBREAKDETECTLENGTH_11B) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart1, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart1, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
